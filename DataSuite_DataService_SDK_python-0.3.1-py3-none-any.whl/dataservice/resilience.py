import time
import logging

def retry(func):
    def wrapper(self, **kwargs):
        logger = logging.getLogger(self.__class__.__name__)
        status = False
        response = func(self=self, **kwargs)
        if response.status_code == 200:
            return response
        if response.status_code == 400:
            raise RuntimeError("there is the request parameter incorrectness. ", response.content)
        elif response.status_code == 401:
            self.refresh()
            return func(self=self, **kwargs)
        elif response.status_code == 403:
            logging.warning(str(response.content) + ". Forced refresh token and retry once.")
            self.refresh()
            response = func(self=self, **kwargs)
            if response.status_code == 200:
                return response
            else:
                raise RuntimeError("The app has no access to the api declared. ", response.content)
        elif response.status_code == 404:
            raise RuntimeError("404 Not Found. ", response.content)
        elif response.status_code == 500:
            raise RuntimeError("500 Internal Server Error. ", response.content)
        elif response.status_code == 429:
            timer = 1
            while timer <= 10 and response.status_code == 429:
                logger.warning("request has exceeded the rate limit. hold for 5s, attempt " + str(timer))
                time.sleep(5)
                response = func(self=self, **kwargs)
                timer += 1
            return response
        else:
            return response
            
    return wrapper