from Crypto.Cipher import AES
import base64

class AESCipher:

    def __init__(self, key, iv):
        if len(key) > 32:
            key = key[:32]
        while len(key) % 32 != 0:
            key += '\0'
        self.key = key.encode('utf-8')
        self.iv = base64.b64decode(iv)

    @staticmethod
    def un_pad(text):
        return text[:-ord(text[len(text) - 1:])]

    def decrypt(self, encrypted_text):
        encrypted_text = base64.b64decode(encrypted_text)
        cipher = AES.new(key=self.key, mode=AES.MODE_CBC, IV=self.iv)
        decrypted_text = cipher.decrypt(encrypted_text)
        return self.un_pad(decrypted_text).decode('utf-8')