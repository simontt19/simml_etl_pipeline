import gzip
import json
import logging
import time

import requests

from dataservice.aes import AESCipher
from dataservice.query_configuration import QueryConfiguration
from dataservice.resilience import retry


class Client():
    _proxies = None
    _timeout = 5
    _scope = []

    def __init__(self):
        self.duration = None
        self.engine = None
        self.pageSize = None
        self.pageNum = None

    def create(self):
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.headers = {
            "Content-Type": "application/json",
            "DataService-SDK-Client": "0.3.1",
            "DataService-SDK-Type": "python",
            "DataService-Compression-Format": "GZIP"
        }
        self.token = None
        self.logger.info("create a new instance of dataservice sdk client.")
        return self

    def appKey(self, appKey):
        self.appKey = appKey
        return self

    def appSecret(self, appSecret):
        self.appSecret = appSecret
        return self

    def queryPattern(self, queryPattern):
        self.queryPattern = queryPattern
        return self

    def shardCapacity(self, shardCapacity):
        self.shardCapacity = shardCapacity
        return self

    def env(self, env):
        self.env = env
        return self

    def proxies(self, proxies):
        self._proxies = proxies
        return self

    def timeout(self, timeout):
        self._timeout = timeout
        return self

    def key(self, key):
        self.key = key
        return self

    def scope(self, scope):
        self._scope = scope
        return self

    def fsHeader(self, appKey, Authorization, key):
        self.headers['appKey'] = appKey
        self.headers['Authorization'] = Authorization
        self.headers['key'] = key
        return self

    def refresh(self):
        assert self.appKey is not None
        assert self.appSecret is not None

        url = QueryConfiguration.Env.EXTRANET + "/oauth/token"
        self.headers.pop('Authorization', None)

        params = {
            "client_id": self.appKey,
            "client_secret": self.appSecret,
            "grant_type": "client_credentials"
        }
        if len(self._scope) > 0:
            params['scope'] = " ".join(self._scope)

        response = requests.post(
            url,
            params=params,
            headers=self.headers,
            proxies=self._proxies
        )

        if response.status_code == 401:
            self.logger.error(
                "Can't refresh token with the app key and app secret. Please check the correctness of your config.")
            raise RuntimeError(response.json())

        jwt = response.json()
        self.token = jwt['access_token']
        self.headers['Authorization'] = "Bearer " + self.token
        self.token_type = jwt['token_type']
        self.expires_in = int(jwt['expires_in'])
        self.scope = jwt['scope']
        self.authorities = jwt['authorities']
        self.jti = jwt['jti']
        self.expiry_timestamp = int(time.time()) + int(self.expires_in)
        self.logger.info(
            "successfully refreshed a new session of dataservice api.")
        return self

    # For All APIs query, support custom Env, QueryPattern, ApiName, Version, EncryptKey, and RequestBody
    # For OLAP API query, support custom PrestoQueueName, EnableCache, and ShardCapacity
    def callWithQueryConfig(self, queryConfig):
        assert queryConfig.apiName is not None
        assert queryConfig.version is not None
        if queryConfig.queryPattern is None:
            queryConfig.queryPattern = self.queryPattern
        if queryConfig.queryPattern == 0:
            return self.__query_olap_(queryConfig)
        elif queryConfig.queryPattern == 1:
            return self.__query_kv_(queryConfig)
        elif queryConfig.queryPattern == 2:
            return self.__query_fs_(queryConfig)
        elif queryConfig.queryPattern == 3:
            return self.__query_olap_speedup_(queryConfig)
        else:
            raise RuntimeError("The Client has incorrect QueryPattern.")

    def call(self, api_abbr, version, body=None, queue=None, enable_cache=True):
        queryConfig = QueryConfiguration(apiName=api_abbr, version=version,
                                         requestBody=body,
                                         prestoQueueName=queue,
                                         enableCache=enable_cache)
        return self.callWithQueryConfig(queryConfig)

    # Support custom Env, ApiName, Version, PrestoQueueName, RequestBody, EnableCache, and ShardCapacity
    def callAsyncWithQueryConfig(self, queryConfig):
        api_abbr = queryConfig.apiName
        version = queryConfig.version
        queue = queryConfig.prestoQueueName
        enable_cache = queryConfig.enableCache
        body = queryConfig.requestBody
        if queryConfig.env is None:
            env = self.env
        else:
            env = queryConfig.env
        if queryConfig.shardCapacity is None:
            shard_capacity = self.shardCapacity
        else:
            shard_capacity = queryConfig.shardCapacity

        service_path = "/dataservice/" + api_abbr + "/" + version
        url = env + service_path

        # check queue info
        if 'prestoQueueName' not in body['prestoPayload'] and queue:
            body['prestoPayload']['prestoQueueName'] = queue

        logging.info(
            "execute OLAP query. enableCache: %s. apiAbbr: %s, version: %s, body: %s\n",
            enable_cache, api_abbr, version, body)
        # submit a query
        response = self.__execute_olap_query(url=url, body=body,
                                             enable_cache=enable_cache,
                                             shard_capacity=shard_capacity,
                                             query_pattern=queryConfig.queryPattern)
        logging.info("jobId: %s", response.headers['JobUuid'])
        if response.headers['Content-Type'] == 'application/json':
            json_content = response.json()
        elif response.headers['Content-Type'] == 'application/octet-stream':
            json_content = json.loads(gzip.decompress(response.content))
        else:
            raise RuntimeError("unknown response header. Content-Type: " + response.headers['Content-Type'])
        if 'jobId' in json_content:
            job_id = json_content['jobId']
            return job_id
        elif 'previewStatus' in json_content and json_content[
            'previewStatus'] == 'ERROR':
            raise RuntimeError(json_content['message'])
        else:
            return json_content

    def callAsync(self, api_abbr, version, body, queue, enable_cache=True):
        queryConfig = QueryConfiguration(apiName=api_abbr, version=version,
                                         requestBody=body,
                                         prestoQueueName=queue,
                                         enableCache=enable_cache)
        return self.callAsyncWithQueryConfig(queryConfig)

    # Support custom Env and EncryptKey
    def fetchAsyncWithQueryConfig(self, job_id, queryConfig):
        if queryConfig.env is None:
            env = self.env
        else:
            env = queryConfig.env
        startTime = int(time.time())
        # waiting for meta to be rendered
        status = 'RUNNING'
        while status == 'RUNNING':
            time.sleep(3)
            url = env + "/dataservice/result/" + job_id
            response = self.__fetch_olap_meta(url=url)
            if response.status_code == 200:
                metadata = response.json()
                status = metadata['status']
            if startTime + queryConfig.olapStatusCheckTimeout < int(time.time()):
                raise RuntimeError("olap status check timeout")

        if status == 'FINISH':
            pass
        else:
            raise RuntimeError(metadata['message'])

        self.engine = metadata['engine']
        self.pageNum = metadata.get('pageNum', None)
        self.pageSize = metadata.get('pageSize', None)
        self.duration = int(metadata['finishedTimestamp']) - int(metadata['startTimestamp'])
        max_shard = int(metadata['maxShard'])
        encrypted = metadata["encrypted"]

        columns = []
        for i in range(max_shard + 1):
            logging.info("fetch OLAP result. shard: %d, total shard: %d\n", i, max_shard)
            url = env + "/dataservice/result/" + job_id + "/" + str(i)
            r = self.__fetch_olap_result(url=url)
            f = gzip.decompress(r.content)
            result = json.loads(f.decode("utf-8"))
            if i == 0:
                columns = result['co']
            if encrypted:
                if queryConfig.encryptKey is None:
                    key = self.key
                else:
                    key = queryConfig.encryptKey
                decryptor = AESCipher(key, result['iv'])
                yield self.__format_result(columns,
                                           decryptor.decrypt(result['rows']))
            else:
                yield self.__format_result(columns, result['value'])
            logging.info("fetch shard: %d result complete.\n", i)

    def fetchAsync(self, job_id):
        return self.fetchAsyncWithQueryConfig(job_id, QueryConfiguration())

    def __query_olap_(self, queryConfig):
        response_content = self.callAsyncWithQueryConfig(queryConfig)
        if type(response_content) is str:
            for i in self.fetchAsyncWithQueryConfig(response_content,
                                                    queryConfig):
                yield i
        elif type(response_content) is dict:
            yield response_content
        else:
            raise RuntimeError(
                "Unexpected response, the api can't be detected the request type.")

    @retry
    def __execute_olap_query(self, **kwargs):
        body = kwargs['body']
        if 'body' not in kwargs:
            body = {}
        action = "query olap api"
        headers = self.headers
        headers['dataservice-enable-cache'] = str(kwargs['enable_cache'])
        shardCapacity = kwargs['shard_capacity']
        if isinstance(shardCapacity, int):
            assert shardCapacity >= 2000
            assert shardCapacity <= 40000
            self.headers['Dataservice-Shard-Capacity'] = str(shardCapacity)
        if kwargs['query_pattern'] == 3:
            params = {"olapSpeedUp": "true"}
        else:
            params = {}
        response = requests.post(kwargs['url'], headers=headers, json=body,
                                 params=params, timeout=self._timeout,
                                 proxies=self._proxies)
        return response

    @retry
    def __fetch_olap_meta(self, **kwargs):
        action = "fetch olap result metadata"
        response = requests.get(kwargs['url'], headers=self.headers,
                                timeout=self._timeout, proxies=self._proxies)
        return response
    
    @retry
    def __fetch_olap_result(self, **kwargs):
        action = "fetch olap result shard"
        response = requests.get(kwargs['url'], headers=self.headers,
                                timeout=self._timeout, proxies=self._proxies)
        return response

    def __query_olap_speedup_(self, queryConfig):
        response_content = self.callAsyncWithQueryConfig(queryConfig)
        return response_content['rows']

    def __query_kv_(self, queryConfig):
        service_path = "/dataservice/" + queryConfig.apiName + "/" + queryConfig.version
        if queryConfig.env is None:
            env = self.env
        else:
            env = queryConfig.env
        url = env + service_path
        # submit a query
        response = self.__fetch_kv_result(url=url, body=queryConfig.requestBody)
        logging.info("jobId: %s", response.headers['JobUuid'])
        result = response.json()
        if 'encryptionAlgo' in result:
            if queryConfig.encryptKey is None:
                key = self.key
            else:
                key = queryConfig.encryptKey
            decryptor = AESCipher(key, result['iv'])
            return decryptor.decrypt(result['data'])
        else:
            return result['kvQueryData']

    @retry
    def __fetch_kv_result(self, **kwargs):
        body = kwargs['body']
        if 'body' not in kwargs:
            body = {}
        action = "fetch kv result"
        response = requests.post(kwargs['url'], headers=self.headers,
                                 params={"speedUp": "true"}, json=body,
                                 timeout=self._timeout, proxies=self._proxies)
        return response

    def __query_fs_(self, queryConfig):
        service_path = "/dataservice/fs/" + queryConfig.apiName + "/" + queryConfig.version
        if queryConfig.env is None:
            env = self.env
        else:
            env = queryConfig.env
        url = env + service_path
        # submit a query
        response = self.__fetch_fs_result(url=url, body=queryConfig.requestBody)
        result = response.json()
        decryptor = AESCipher(self.headers['key'], result['iv'])
        result['data'] = decryptor.decrypt(result['data'])
        del result['iv']
        return result

    def __fetch_fs_result(self, **kwargs):
        body = [kwargs['body']]
        if 'body' not in kwargs:
            body = {}
        action = "fetch fs result"
        response = requests.post(kwargs['url'], headers=self.headers, json=body,
                                 timeout=self._timeout, proxies=self._proxies)
        return response

    def __format_result(self, columns, values):
        results = []
        if isinstance(values, str):
            values = json.loads(values)
        for i in range(len(values)):
            value = dict(zip(columns, values[i]))
            results.append({'rowNumber': i + 1, 'values': value})
        return results
