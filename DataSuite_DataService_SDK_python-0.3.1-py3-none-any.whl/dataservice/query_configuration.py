from dataservice.body import Body


class QueryConfiguration():
  class QueryPattern:
    OLAP = 0
    KV = 1
    FS = 2
    OLAP_SPEEDUP = 3

  class Env:
    INTRANET = "https://open-api.datasuite.shopee.io"
    EXTRANET = "https://open-api.datasuite.shopeemobile.com"
    LIVE = "https://open-api.datasuite.shopee.io"
    LIVE_PUBLIC_WAN = "https://open-api.datasuite.shopeemobile.com"

  def __init__(self, apiName=None, version=None, encryptKey=None,
      prestoQueueName=None, enableCache=False, shardCapacity=None,
      queryPattern=None, env=None, requestBody=Body,
      olapStatusCheckTimeout=7200):
    self.apiName = apiName
    self.version = version
    self.encryptKey = encryptKey
    self.prestoQueueName = prestoQueueName
    self.enableCache = enableCache
    self.shardCapacity = shardCapacity
    self.queryPattern = queryPattern
    self.env = env
    self.requestBody = requestBody
    self.olapStatusCheckTimeout = olapStatusCheckTimeout
