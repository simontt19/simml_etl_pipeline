class Body():
  def __init__(self, expressions=None, keys=None, profile=None, region=None, fsPayload=None, pageNumber=None, pageSize=None):
    self.prestoPayload = {"expressions": expressions}
    self.kvPayload = {"keys": keys}
    self.header = {"profile": profile, "region": region}
    self.payload = fsPayload
    self.pageNumber = pageNumber
    self.pageSize = pageSize

class Expressions():
    expressions = []

    def addExpression(self, parameterName, value):
        self.expressions.append({"parameterName": parameterName, "value": value})
        return self

    def getExpressions(self):
        expr = self.expressions
        Expressions.expressions = []
        return expr

class Keys():
    keys = []

    def addKeyValue(self, key, value):
        assert len(key) == len(value), 'key and value must correspond one to one.'
        keyValues = {}
        for i in range(len(key)):
          keyValues[key[i]] = value[i]
        self.keys.append(keyValues)
        return self

    def getKeys(self):
        return self.keys;

class FSPayload():
    fsPayload = {}

    def setFSPayload(self, rowkeys, columns):
        assert len(rowkeys) == len(columns), 'rowkeys and columns slice must correspond one to one.'
        for i in range(len(rowkeys)):
          self.fsPayload[rowkeys[i]] = columns[i]
        return self.fsPayload